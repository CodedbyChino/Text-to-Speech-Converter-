import json
import boto3

# Initialize Polly and S3 clients
polly_client = boto3.client('polly')
s3_client = boto3.client('s3')

def text_to_speech(file_name, source_bucket, destination_bucket):
    # Read text content from the source S3 object
    response = s3_client.get_object(Bucket=source_bucket, Key=file_name)
    text = response['Body'].read().decode('utf-8')

    # Use Amazon Polly to synthesize speech
    polly_response = polly_client.synthesize_speech(
        OutputFormat='mp3',  # Specify desired output format
        Text=text,
        VoiceId='Matthew'     # Choose a Polly voice
    )

    # Upload synthesized speech to the destination S3 bucket
    destination_key = file_name.replace('.txt', '.mp3')
    s3_client.put_object(
        Bucket=destination_bucket,
        Key=destination_key,
        Body=polly_response['AudioStream'].read()  # Read the audio stream
    )

def lambda_handler(event, context):
    # Extract bucket and file information from the event
    source_bucket = "source-bucket"
    
    # Check if 'Records' key is present in the event
    if 'Records' in event and len(event['Records']) > 0:
        file_key = event['Records'][0]['s3']['object']['key']

        # Specify the destination S3 bucket
        destination_bucket = "destination-bucket"

        # Convert text to speech and save the MP3 file to the destination bucket
        text_to_speech(file_key, source_bucket, destination_bucket)

        return "Text-to-speech conversion completed successfully."
    else:
        return "No 'Records' found in the event."